
#ifndef SORT_H
#define SORT_H

#include <vector>
#include <iostream>

using namespace std;

// Create the Sort class header files, define the functions in Sort.cpp
class Sort {
private:

public:
    void InsertionS(vector<int>& Data, vector<double>& keys, int& CompCount);

    void QuickS(vector<int>& Data, vector<double>& keys, int Left, int Right, int& CompCount);

    void MergeS(vector<int>& Data, vector<double>& keys, int Left, int Right, int& CompCount);

    int Partition(vector<int>& Data, int Left, int Right, int& CompCount);

    void Merge(vector<int>& Data, vector<double>& keys, int Left, int Mid, int Right, int& CompCount);

    void DisplayInsertion(vector<int> UnsortedData, vector<int> SortedData, int CompCount);

    void DisplayMerge(vector<int> UnsortedData, vector<int> SortedData, int CompCount);

    void DisplayQuick(vector<int> UnsortedData, vector<int> SortedData, int CompCount);
 
};
#endif