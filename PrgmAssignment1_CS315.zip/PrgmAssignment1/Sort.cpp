#include "Sort.h"

using namespace std;
    // I used pass by reference to simplify the functions to void, and did the indexing at 0 becasue I'm not a criminal
    void Sort::InsertionS(vector<int>& Data, vector<double>& keys, int& CompCount) {
        // Follow the pseudocode from in class
        for (int j = 1; j < Data.size(); j++) {
            int key = Data[j];
            int i = j-1;
            int startI = i;
            CompCount++;
            while (i >= 0 && Data[i] > key) {
                if (i != startI) {
                    CompCount++;
                }
                Data[i+1] = Data[i];
                i--;
            }
            Data[i+1] = key;
        }
    } 
    void Sort::MergeS(vector<int>& Data, vector<double>& keys, int Left, int Right, int& CompCount) {
        // Follow the pseudocode from in class
        if (Left < Right) {
            int Mid = (Left+Right)/2;
            MergeS(Data, keys, Left, Mid, CompCount);
            MergeS(Data, keys, Mid+1, Right, CompCount);
            Merge(Data, keys, Left, Mid, Right, CompCount);
        }
    }
    void Sort::QuickS(vector<int>& Data, vector<double>& keys, int Left, int Right, int& CompCount) {
        // Follow the pseudocode from in class
        if (Left < Right) {
            int Mid = Partition(Data, Left, Right, CompCount);
            QuickS(Data, keys, Left, Mid-1, CompCount);
            QuickS(Data, keys, Mid+1, Right, CompCount);
        }
    }
    void Sort::DisplayInsertion(vector<int> UnsortedData, vector<int> SortedData, int CompCount) {
        // Create the display
        cout << "Sorted Data via Insertion Sort: ";
        for (int i = 0; i < SortedData.size(); i++) {
            if (i == SortedData.size()-1) {
                cout << SortedData[i] << endl << endl;
                cout << "Number of Comparisons Insertion Sort: " << CompCount << endl << endl;
            }
            else {
                cout << SortedData[i] << ",";
            }
        }
    }
    void Sort::DisplayMerge(vector<int> UnsortedData, vector<int> SortedData, int CompCount) {
        // Create the display
        cout << "Sorted Data via Merge Sort: ";
        for (int i = 0; i < SortedData.size(); i++) {
            if (i == SortedData.size()-1) {
                cout << SortedData[i] << endl << endl;
                cout << "Number of Comparisons Merge Sort: " << CompCount << endl << endl;
            }
            else {
                cout << SortedData[i] << ",";
            }
        }
    }
    void Sort::DisplayQuick(vector<int> UnsortedData, vector<int> SortedData, int CompCount) {
        // Create the display
        cout << "Sorted Data via Quick Sort: ";
        for (int i = 0; i < SortedData.size(); i++) {
            if (i == SortedData.size()-1) {
                cout << SortedData[i] << endl << endl;
                cout << "Number of Comparisons Quick Sort: " << CompCount << endl << endl;
            }
            else {
                cout << SortedData[i] << ",";
            }
        }
    }

    int Sort::Partition(vector<int>& Data, int Left, int Right, int& CompCount) {
        // Follow the pseudocode
        int x = Data[Right];
        int i = Left-1;
        for (int j = Left; j <= Right-1; j++) {
            CompCount++;
            if (Data[j] <= x) {
                i++;
                swap(Data[i], Data[j]);
            }
        }
        swap(Data[i+1], Data[Right]);
        return i+1;
    }
    void Sort::Merge(vector<int>& Data, vector<double>& keys, int Left, int Mid, int Right, int& CompCount) {
        // Follow the pseudocode
        int n1 = Mid-Left+1;
        int n2 = Right-Mid;
        vector<int> L;
        vector<int> R;
        for (int i = 0; i < n1; i++) {
            L.push_back(Data[Left+i]);
        }
        for (int j = 0; j < n2; j++) {
            R.push_back(Data[Mid+j+1]);
        }
        L.push_back(123456789);
        R.push_back(123456789);
        int i = 0;
        int j = 0;
        for (int k = Left; k <= Right; k++) {
            CompCount++;
            if (L[i] < R[j]) {
                Data[k] = L[i];
                i++;
            }
            else {
                Data[k] = R[j];
                j++;
            }
        }
    }