// Author: Raymond Goodman
// Date: 2/1/2024
// Purpose: Learn how to implement Insertion sort, merge sort, and quicksort
// Sources: 
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include "Sort.h"

using namespace std;

int main(int argc, char* argv[]) {
    // Create and switch between all the csv files, loop trhough them to sort
    string csvFile;
    for (int itr = 0; itr < 9; itr++) {
        switch(itr) {
            case 0:
                csvFile = "pokemonRandomLarge.csv";
                break;
            case 1:
                csvFile = "pokemonRandomMedium.csv";
                break;
            case 2:
                csvFile = "pokemonRandomSmall.csv";
                break;
            case 3:
                csvFile = "pokemonReverseSortedLarge.csv";
                break;
            case 4:
                csvFile = "pokemonReverseSortedMedium.csv";
                break;
            case 5:
                csvFile = "pokemonReverseSortedSmall.csv";
                break;
            case 6:
                csvFile = "pokemonSortedLarge.csv";
                break;
            case 7:
                csvFile = "pokemonSortedMedium.csv";
                break;
            case 8:
                csvFile = "pokemonSortedSmall.csv";
                break;
            default:
                break;
        }
    
        // Read in the file and place the data in their respective vectors
        ifstream file(csvFile);

        if (!file.is_open()) {
            return 0;
        }
        vector<double> PokemonKey;
        vector<int> PowerLevel;

        string line;
        getline(file, line);
        while(getline(file, line)){
            istringstream iss(line);
            double key;
            int power;
            char delimiter = ',';

            if (!(iss >> key >> delimiter >> power)) {
                cerr << "Error reading line: " << line << endl;
                continue;
            }
            else {
                PokemonKey.push_back(key);
                PowerLevel.push_back(power);
            }
        }
        file.close();

        //Copy the data into their own vectors so each sorting algorithm does its own sort
        vector<int> InsertionData;
        vector<int> MergeData;
        vector<int> QuickData;
        for (int i = 0; i < PowerLevel.size(); i++) {
            InsertionData.push_back(PowerLevel[i]);
            MergeData.push_back(PowerLevel[i]);
            QuickData.push_back(PowerLevel[i]);
        }

        vector<double> InsertionKeys;
        vector<double> MergeKeys;
        vector<double> QuickKeys;
        for (int j = 0; j < PokemonKey.size(); j++) {
            InsertionKeys.push_back(PokemonKey[j]);
            MergeKeys.push_back(PokemonKey[j]);
            QuickKeys.push_back(PokemonKey[j]);
        }

        Sort s; //Create an instance of the class
    
        // Create the comparison counters
        int InsertionCount = 0;
        int MergeCount = 0;
        int QuickCount = 0;

        // Call the sorting algorithms
        s.InsertionS(InsertionData, InsertionKeys, InsertionCount);
        s.MergeS(MergeData, MergeKeys, 0, MergeData.size() - 1, MergeCount);
        s.QuickS(QuickData, QuickKeys, 0, QuickData.size()-1, QuickCount);

        //Display everything
        cout << "File Name: " << csvFile << endl << endl;
        cout << "Initial Order: ";
        for (int i = 0; i < PowerLevel.size(); i++) {
            if (i == PowerLevel.size()-1) {
                cout << PowerLevel[i] << endl << endl;
            }
            else {
                cout << PowerLevel[i] << ",";
            }
        }
        s.DisplayInsertion(PowerLevel, InsertionData, InsertionCount);
        s.DisplayMerge(PowerLevel, MergeData, MergeCount);
        s.DisplayQuick(PowerLevel, QuickData, QuickCount);
    }
}