import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;
import java.util.Timer;


public class cardMatch implements ActionListener {

    int Matches = 0;
    JLabel Match = new JLabel("Matches: " + Matches);
    String[] ImagePaths = {"src/cardIcons/ace_of_clubs_icon.png", "src/cardIcons/2_of_clubs_icon.png", "src/cardIcons/3_of_clubs_icon.png", "src/cardIcons/4_of_clubs_icon.png", "src/cardIcons/5_of_clubs_icon.png", "src/cardIcons/6_of_clubs_icon.png", "src/cardIcons/7_of_clubs_icon.png", "src/cardIcons/8_of_clubs_icon.png", "src/cardIcons/9_of_clubs_icon.png", "src/cardIcons/10_of_clubs_icon.png", "src/cardIcons/jack_of_clubs2_icon.png", "src/cardIcons/queen_of_clubs2_icon.png", "src/cardIcons/king_of_clubs2_icon.png", "src/cardIcons/ace_of_diamonds_icon.png", "src/cardIcons/2_of_diamonds_icon.png", "src/cardIcons/3_of_diamonds_icon.png", "src/cardIcons/4_of_diamonds_icon.png", "src/cardIcons/5_of_diamonds_icon.png", "src/cardIcons/6_of_diamonds_icon.png", "src/cardIcons/7_of_diamonds_icon.png", "src/cardIcons/8_of_diamonds_icon.png", "src/cardIcons/9_of_diamonds_icon.png", "src/cardIcons/10_of_diamonds_icon.png", "src/cardIcons/jack_of_diamonds2_icon.png", "src/cardIcons/queen_of_diamonds2_icon.png", "src/cardIcons/king_of_diamonds2_icon.png", "src/cardIcons/ace_of_hearts_icon.png", "src/cardIcons/2_of_hearts_icon.png", "src/cardIcons/3_of_hearts_icon.png", "src/cardIcons/4_of_hearts_icon.png", "src/cardIcons/5_of_hearts_icon.png", "src/cardIcons/6_of_hearts_icon.png", "src/cardIcons/7_of_hearts_icon.png", "src/cardIcons/8_of_hearts_icon.png", "src/cardIcons/9_of_hearts_icon.png", "src/cardIcons/10_of_hearts_icon.png", "src/cardIcons/jack_of_hearts2_icon.png", "src/cardIcons/queen_of_hearts2_icon.png", "src/cardIcons/king_of_hearts2_icon.png", "src/cardIcons/ace_of_spades_icon.png", "src/cardIcons/2_of_spades_icon.png", "src/cardIcons/3_of_spades_icon.png", "src/cardIcons/4_of_spades_icon.png", "src/cardIcons/5_of_spades_icon.png", "src/cardIcons/6_of_spades_icon.png", "src/cardIcons/7_of_spades_icon.png", "src/cardIcons/8_of_spades_icon.png", "src/cardIcons/9_of_spades_icon.png", "src/cardIcons/10_of_spades_icon.png", "src/cardIcons/jack_of_spades2_icon.png", "src/cardIcons/queen_of_spades2_icon.png", "src/cardIcons/king_of_spades2_icon.png", "src/cardIcons/cardBack.png"};
    public class DualFaceButton extends JButton {
        private ImageIcon[] faces;
        private int currentFaceIndex;
        private boolean isFront;
        private Timer timer = new Timer();
        private int i;
        private int j;
        private int SelectI = -1;
        private int SelectJ = -1;
        private static int CurrNumFlipped = 0;

        int Rank1 = -1;
        int Rank2 = -1;

        public DualFaceButton(ImageIcon[] faces, int i, int j) {
            super(faces[0]);
            this.faces = faces;
            this.currentFaceIndex = 0;
            this.isFront = true;
            this.i = i;
            this.j = j;

            addActionListener(e -> toggleFace());
            /*timer = new Timer(3000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    //toggleToFront(); // Automatically toggle back to the front after 3 seconds
                    toggleFace();
                }
            });
            timer.setRepeats(false); // Set to false to trigger the timer only once
        */
        }

        /*private void toggleFace() {
            if (isFront) {
                if (CurrNumFlipped < 2) {
                    CurrNumFlipped++;
                    toggleToBack();// Immediately toggle to the back
                    //timer.restart(); // Restart the timer for 3 seconds before toggling back to the front
                    if (CurrNumFlipped == 2) {
                        this.toggleToFront();
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                SwingUtilities.invokeLater(() -> {
                                    toggleToFront();
                                    checkForMatch();
                                    CurrNumFlipped = 0;
                                    //timer.cancel();
                                    //timer = new Timer();
                                });
                            }
                        }, 3000);
                    }
                }
            }
            else {
                CurrNumFlipped--;
                toggleToFront();
                checkForMatch();
                if (CurrNumFlipped == 0) {
                    timer.cancel();
                    timer = new Timer();
                }
                //timer.stop();
            }
            if (CurrNumFlipped == 2) {
                checkForMatch();
            }
        }

        private void toggleToBack() {
            isFront = false;
            setIcon(faces[1]);
            if (CurrNumFlipped == 1) {
                Rank1 = CalcRank();
            }
            else {
                Rank2 = CalcRank();
            }
        }

        private void toggleToFront() {
            isFront = true;
            setIcon(faces[0]);
        }
        private void checkForMatch() {
            System.out.println(Rank1);
            System.out.println(Rank2);
            System.out.println(" ");
            if (Rank1 == Rank2 && Rank1 != -1) {
                Matches++;
                Match.setText("Matches: " + Matches);
                Rank1 = -1;
                Rank2 = -1;
            }
        }
        private int CalcRank() {
            int rank = -1;
            int index = 0;
            ImageIcon MyCard = (ImageIcon) CardBoard[i][j].getIcon();
            ImageIcon TestCard = null;
            while (index < 52) {
                TestCard = new ImageIcon(ImagePaths[index]);
                if (MyCard.getDescription().equals(TestCard.getDescription())) {
                //if (MyCard.getImage().equals(TestCard.getImage())) {
                    rank = index % 13;
                    return rank;
                }
                index++;
            }
            return rank%13;
        }*/

        // Restart the toggle
        





    }
    JButton ResetButton;
    JButton StartButton;
    JButton QuitButton;
    DualFaceButton[][] CardBoard = new DualFaceButton[4][13];
    JFrame frame = new JFrame("Card Match!");
    JPanel cardPanel = new JPanel();
    cardMatch() {
        Dimension ScreenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int FrameWidth = ScreenSize.width;
        int FrameHeight = ScreenSize.height;

        cardPanel.setPreferredSize(new Dimension(FrameWidth, FrameHeight-50));
        cardPanel.setLayout(new GridLayout(4, 13));
        int CardCount = 0;

        for (int i = 0; i < CardBoard.length; i++) {
            for (int j = 0; j < CardBoard[i].length; j++) {
                ImageIcon icon = new ImageIcon(ImagePaths[52]);
                ResizeIcon(icon, 69 , 100);
                ImageIcon[] cardFaces = {icon, new ImageIcon(ImagePaths[CardCount])};
                CardBoard[i][j] = new DualFaceButton(cardFaces, i, j);
                CardBoard[i][j].addActionListener(this);
                CardBoard[i][j].setBackground(Color.WHITE);
                cardPanel.setBounds(0, 0, FrameWidth, (3*FrameHeight)/4);
                cardPanel.add(CardBoard[i][j]);
                CardCount++;
            }
        }
        cardPanel.setBackground(Color.WHITE);
        frame.getContentPane().add(cardPanel);
        Match.setVisible(true);
        Match.setBounds((FrameWidth/2)+280, 725, 160, 30);

        ResetButton = new JButton("Reset");
        ResetButton.setBounds((FrameWidth/2)-80, 725, 160, 30);
        ResetButton.addActionListener(this);

        QuitButton = new JButton("Quit");
        QuitButton.setBounds((FrameWidth/2) - 280, 725, 160, 30);
        QuitButton.addActionListener(this);

        StartButton = new JButton("Start");
        StartButton.setBounds((FrameWidth/2) + 100, 725, 160, 30);
        StartButton.addActionListener(this);

        frame.add(ResetButton);
        frame.add(StartButton);
        frame.add(QuitButton);
        frame.add(Match);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(FrameWidth, FrameHeight);
        frame.setVisible(true);
        cardPanel.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == ResetButton) {
            resetBoard(frame, CardBoard);
        }
        else if (e.getSource() == QuitButton) {
            System.exit(0);
        }
        else if (e.getSource() == StartButton) {
            shuffleBoard(frame, CardBoard);
        }
        else {
            boolean isFront = true;
            //cardPanel.get
        }
    }
    public Action shuffleBoard(JFrame frame, JButton[][] CardBoard) {
        JButton[] Cards = new JButton[52];
        int Spot = 0;
        for (int i = 0; i < CardBoard.length; i++) {
            for (int j = 0; j < CardBoard[i].length; j++) {
                Cards[Spot] = CardBoard[i][j];
                Spot++;
            }
        }
        List<JButton> Deck = Arrays.asList(Cards);
        Collections.shuffle(Deck);
        JButton[] ShuffledDeck = new JButton[52];
        Deck.toArray(ShuffledDeck);
        cardPanel.removeAll();
        int TopCard = 0;
        JButton[][] ShuffledBoard = new JButton[4][13];
        for (int l = 0; l < ShuffledBoard.length; l++) {
            for (int k = 0; k < ShuffledBoard[l].length; k++) {
                ShuffledBoard[l][k] = ShuffledDeck[TopCard];
                TopCard++;
                ShuffledBoard[l][k].setBackground(Color.WHITE);
                cardPanel.add(ShuffledBoard[l][k]);

            }
        }
        cardPanel.repaint();
        cardPanel.revalidate();
        frame.revalidate();
        frame.repaint();
        return null;
    }
    public Action resetBoard(JFrame frame, DualFaceButton[][] CardBoard) {
        cardPanel.removeAll();
        for (int i = 0; i < CardBoard.length; i++){
            for (int j = 0; j < CardBoard[i].length; j++){
                cardPanel.add(CardBoard[i][j]);
            }
        }
        Matches = 0;
        Match.setText("Matches: " + Matches);
        cardPanel.repaint();
        cardPanel.revalidate();
        frame.revalidate();
        frame.repaint();
        return null;
    }
    public ImageIcon ResizeIcon(ImageIcon icon, int Width, int Height) {
        Image image = icon.getImage();
        Image resizedImage = image.getScaledInstance(Width, Height, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImage);
    }
    public static void main(String[] args) {
        new cardMatch();
    }
}

